This font is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License. as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This font is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

Please understand that I just don�t have the time to answer questions
about installing and using this font. Read your operating system's manual
or search internet for information on this matter.

------------------------------------------------------------------------------

History

Known problems:
In some cases font sizes the font is pixelly and grainy.
The line spacing is greater than with the .fon variant.

Anyone who feels called upon to improve this is welcome to do his best.

Version 5.00c (17.02.2003):
Character 0x96 is now assigned to a symbol.

Version 5.00b (27.01.2003):
Character 0xE5's (�) ring is not closed.
The null is now correctly positioned and no longer to far to the right.

Version 5.00a (04.12.2002):
This is my first more-or-less definitive version.
The Euro symbol is a bonus.

Until Version 4:
Markus Gebhard's versions of fixedsys.ttf with many new characters
compared to the original version.

Source:
The first version of fixedsys.ttf originated with Travis Owens. He
stopped development and released the font for further improvement.