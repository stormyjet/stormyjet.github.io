#!/bin/bash
scp ./docs/assets/css/bootstrap.css 9ol.es:/usr/qaa.ath.cx/www/BOOTSTRA.386/assets/css/
